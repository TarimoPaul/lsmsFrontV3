package com.Lsms.Sales.Dto;

import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Positive;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * One replacement product of an EXCHANGE return. Priced by the server (same rules as
 * a POS sale) when the exchange is approved and the new sale is made.
 */
@Data
@NoArgsConstructor
@AllArgsConstructor
public class ExchangeLineDto {

    @NotBlank(message = "Product UID is required")
    private String productUid;

    /** PIECES, QUARTER_PACKAGE, HALF_PACKAGE or WHOLE_PACKAGE (default PIECES). */
    private String saleType;

    /** How many of saleType (pieces for PIECES, packs otherwise). */
    @NotNull(message = "Quantity is required")
    @Positive(message = "Quantity must be positive")
    private Integer packageQuantity;
}
