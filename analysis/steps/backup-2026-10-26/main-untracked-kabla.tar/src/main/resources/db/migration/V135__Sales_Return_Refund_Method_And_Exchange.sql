-- Sales returns: how the refund left the shop, and what an EXCHANGE gives back.
--
-- refund_method         : CASH / VODACOM / CRDB ... — the GL cash account and the
--                         reconciliation deduction follow it (only CASH leaves the drawer).
-- exchange_lines        : JSON list of the replacement products of an EXCHANGE
--                         [{productUid, saleType, packageQuantity}], turned into a new
--                         sale when the exchange is approved.
-- exchange_paid_amount  : money the customer added on top of the returned value.
-- exchange_paid_method  : how that top-up was paid.
--
-- All nullable and additive: existing rows keep their meaning (null method = CASH).

ALTER TABLE sales_returns ADD COLUMN IF NOT EXISTS refund_method VARCHAR(30);
ALTER TABLE sales_returns ADD COLUMN IF NOT EXISTS exchange_lines TEXT;
ALTER TABLE sales_returns ADD COLUMN IF NOT EXISTS exchange_paid_amount NUMERIC(19, 2);
ALTER TABLE sales_returns ADD COLUMN IF NOT EXISTS exchange_paid_method VARCHAR(30);
